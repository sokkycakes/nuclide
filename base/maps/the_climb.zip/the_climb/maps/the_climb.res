// the_climb.res - created with RESGen v2.0.2.
// RESGen is made by Jeroen "ShadowLord" Bogers,
// with serveral improvements and additions by Zero3Cool.
// For more info go to http://resgen.hltools.com

// .res entries (11):
gfx/env/blackbk.tga
gfx/env/blackdn.tga
gfx/env/blackft.tga
gfx/env/blacklf.tga
gfx/env/blackrt.tga
gfx/env/blackup.tga

sound/ambience/burning1.wav
sound/ambience/industrial4.wav

sprites/enter1.spr
sprites/fire.spr

//maps/the_climb.bsp
maps/the_climb.res
maps/the_climb.txt
